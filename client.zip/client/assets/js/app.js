  var myApp = angular.module('myApp', [
      'ui.router',
      'ngAnimate',
      'as.sortable',
      'ngQuickDate',
      'ngTouch',
      /*'ngValidate',*/
      'gg.vmsgs',
      'ngSanitize',
      'cfp.loadingBar',
      //foundation
      // 'ui.bootstrap',
      'foundation',
      'foundation.dynamicRouting',
      'foundation.dynamicRouting.animations',

  ], function($compileProvider) {
      $compileProvider.imgSrcSanitizationWhitelist(/^\s*(https?|ftp|file|chrome-extension|ms-appx-web|ms-appx):|data:image\//);
      $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|ftp|mailto|file|chrome-extension|ms-appx-web|ms-appx):/);



  });


  myApp.config(['$stateProvider', '$urlRouterProvider', '$httpProvider',
          function($stateProvider, $urlRouterProvider, $httpProvider) {


              /* Pregress bar Style */
              // delete $httpProvider.defaults.headers.common['X-Requested-With'];

              // $httpProvider.defaults.headers.common['Access-Control-Allow-Origin'] = '*';

              // $httpProvider.defaults.headers.get = {};

              // $httpProvider.defaults.useXDomain = true;

              $urlRouterProvider.otherwise('/login');

              /* Login States */

              $stateProvider.state('login', {
                  url: '/login',
                  templateUrl: 'templates/login/login.html',
                  controller: 'loginController',
                  animation: {
                      enter: 'slideInLeft'
                  }
              }).state('loginsucess', {
                  url: '/authentication',
                  templateUrl: 'templates/login/loginSuccess.html',
                  controller: 'loginController',
                  animation: {
                      enter: 'slideInLeft'
                  }
              }).state('loginfailure', {
                  url: '/loginfailure',
                  templateUrl: 'templates/login/loginFail.html',
                  animation: {
                      enter: 'slideInLeft'
                  }
                  // controller: 'loginValidation'
              }).state('forgotPassword', {
                  url: '/forgotPassword',
                  templateUrl: 'templates/login/forgotPassword.html',
                  controller: 'loginController',
                  animation: {
                      enter: 'slideInLeft'
                  }
              }).state('help', {
                  url: '/help',
                  templateUrl: 'templates/login/help.html',
                  controller: 'HelpController',
                  animation: {
                      enter: 'slideInLeft'
                  }
              }).state('existinguser', {
                  url: '/existinguser',
                  templateUrl: 'templates/login/existinguser.html',
                  controller: 'loginController',
                  animation: {
                      enter: 'slideInLeft'
                  }
              })

              /* Links */

              .state('usefullinks', {
                  url: '/links',
                  animation: {
                      enter: 'slideInLeft'
                  },
                  views: {
                      '': {
                          templateUrl: 'templates/links/links.html',
                          controller: 'homeController'
                      },
                      'profile@usefullinks': {
                          templateUrl: 'templates/utilities/profile.html',
                          controller: 'profileController'

                      }
                  }
              })


              /* RFP Questions */

              .state('rfpQuestions', {
                  url: '/rfpQuestions',
                  animation: {
                      enter: 'slideInLeft'
                  },
                  views: {
                      '': {
                          templateUrl: 'templates/rfp/rfpQuestions.html',
                          controller: 'rfpQuestionController'
                      },
                      'profile@rfpQuestions': {
                          templateUrl: 'templates/utilities/profile.html',
                          controller: 'profileController'
                      }
                  }
              }).state('rfpQuestionDetail', {
                  url: '/rfpQuestionDetail',
                  animation: {
                      enter: 'slideInLeft'
                  },
                  views: {
                      '': {
                          templateUrl: 'templates/rfp/rfpQuestionDetail.html',
                          controller: 'rfpQuesAnsController'
                      },
                      'profile@rfpQuestionDetail': {
                          templateUrl: 'templates/utilities/profile.html',
                          controller: 'profileController'
                      }
                  }
              }).state('rfpcatagory', {
                  url: '/rfpcatagory',
                  animation: {
                      enter: 'slideInLeft'
                  },
                  views: {
                      '': {
                          templateUrl: 'templates/rfp/quesAnslist.html',
                          controller: 'rfpCatagoryController'
                      },
                      'profile@rfpcatagory': {
                          templateUrl: 'templates/utilities/profile.html',
                          controller: 'profileController'
                      }
                  }
              }).state('createQuestions', {
                  url: '/createQuestions',
                  animation: {
                      enter: 'slideInLeft'
                  },
                  views: {
                      '': {
                          templateUrl: 'templates/rfp/createQuestions.html',
                          controller: 'createquestionsController'
                      },
                      'profile@createQuestions': {
                          templateUrl: 'templates/utilities/profile.html',
                          controller: 'profileController'
                      }
                  }
              })

              /* create Document */
              .state('createdocument', {
                  url: '/createdoc',
                  animation: {
                      enter: 'slideInLeft'
                  },
                  views: {
                      '': {
                          templateUrl: 'templates/newcase/createdoc.html',
                          controller: 'createController'
                      },
                      'profile@createdocument': {
                          templateUrl: 'templates/utilities/profile.html',
                          controller: 'profileController'
                      }
                  }
              }).state('createdocument.step1', {
                  url: '/step1',
                  templateUrl: 'templates/newcase/createdoc-step1.html',
                  controller: 'createdocController',
                  animation: {
                      enter: 'slideInLeft'
                  }
              }).state('createdocument.step2', {
                  url: '/step2',
                  controller: 'createdocumentSecondController',
                  animation: {
                      enter: 'none'
                  },
                  templateUrl: 'templates/newcase/createdoc-step2.html'
              }).state('createdocument.step3', {
                  url: '/step3',
                  templateUrl: 'templates/newcase/createdoc-step3.html',
                  controller: 'createdocstep3Controller',
                  animation: {
                      enter: 'none'
                  },
              }).state('doccreated', {
                  url: '/doccreated',
                  animation: {
                      enter: 'slideInLeft'
                  },
                  templateUrl: 'templates/newcase/doccreated.html',
                  controller: 'docCreated'
              })

              .state('buildDocumentreview', {
                  url: '/reviewBuildDocument',
                  animation: {
                      enter: 'slideInLeft'
                  },
                  views: {
                      '': {
                          templateUrl: 'templates/newcase/reviewbuildDocument.html',
                          controller: 'reviewBuildDocumentController'
                      },
                      'profile@buildDocumentreview': {
                          templateUrl: 'templates/utilities/profile.html',
                          controller: 'profileController'
                      }
                  }
              })

              /* My Work */

              .state('viewProjects', {
                  url: '/viewProjects',
                  animation: {
                      enter: 'slideInLeft'
                  },
                  views: {
                      '': {
                          templateUrl: 'templates/work/viewProjects.html',
                          controller: 'viewProjectController'
                      },
                      'profile@viewProjects': {
                          templateUrl: 'templates/utilities/profile.html',
                          controller: 'profileController'
                      }
                  }
              }).state('myWork', {
                  url: '/myWork',
                  animation: {
                      enter: 'slideInLeft'
                  },
                  views: {
                      '': {
                          templateUrl: 'templates/work/myWork.html',
                          controller: 'myWorkController'
                      },
                      'profile@myWork': {
                          templateUrl: 'templates/utilities/profile.html',
                          controller: 'profileController'
                      }
                  }
              }).state('buildDocument', {
                  url: '/buildDocument/',
                  animation: {
                      enter: 'slideInLeft'
                  },
                  views: {
                      '': {
                          templateUrl: 'templates/work/buildDocument.html',
                          controller: 'buildDocumentController'
                      },
                      'profile@buildDocument': {
                          templateUrl: 'templates/utilities/profile.html',
                          controller: 'profileController'
                      }
                  }
              }).state('viewProjectDetails', {
                  url: '/viewProjectDetails/:index',
                  animation: {
                      enter: 'slideInLeft'
                  },
                  views: {
                      '': {
                          templateUrl: 'templates/work/viewProjectDetails.html',
                          controller: 'viewProjectDetailController'
                      },
                      'profile@viewProjectDetails': {
                          templateUrl: 'templates/utilities/profile.html',
                          controller: 'profileController'
                      }
                  }
              }).state('viewTask', {
                  url: '/viewTask/:index',
                  animation: {
                      enter: 'slideInLeft'
                  },
                  views: {
                      '': {
                          templateUrl: 'templates/work/viewTask.html',
                          controller: 'viewTaskcontroller'
                      },
                      'profile@viewTask': {
                          templateUrl: 'templates/utilities/profile.html',
                          controller: 'profileController'
                      }
                  }
              }).state('viewtaskDetails', {
                  url: '/viewtaskDetails/:index',
                  animation: {
                      enter: 'slideInLeft'
                  },
                  views: {
                      '': {
                          templateUrl: 'templates/work/viewtaskDetails.html',
                          controller: 'viewtaskDetailsController'
                      },
                      'profile@viewtaskDetails': {
                          templateUrl: 'templates/utilities/profile.html',
                          controller: 'profileController'
                      }
                  }
              }).state('favoritesView', {
                  url: '/favoritesView/:index',
                  animation: {
                      enter: 'slideInLeft'
                  },
                  views: {
                      '': {
                          templateUrl: 'templates/work/favoritesView.html',
                          controller: 'favourtecontroller'
                      },
                      'profile@favoritesView': {
                          templateUrl: 'templates/utilities/profile.html',
                          controller: 'profileController'
                      }
                  }
              })

              /* Common Utilities */
              .state('error', {
                      url: '/error',
                      templateUrl: 'templates/utilities/error.html',
                      animation: {
                          enter: 'slideInLeft'
                      }
                  }).state('underConstruction', {
                      url: '/underConstruction',
                      templateUrl: 'templates/utilities/underConstruction.html',
                      animation: {
                          enter: 'slideInLeft'
                      }
                  }).state('home', {
                      url: '/home',
                      animation: {
                          enter: 'slideInLeft'
                      },
                      views: {
                          '': {
                              templateUrl: 'templates/utilities/dashboard.html',
                              controller: 'homeController',
                          },
                          'profile@home': {
                              templateUrl: 'templates/utilities/profile.html',
                              controller: 'profileController'
                          }
                      }
                  }).state('mySettings', {
                      url: '/mySettings',
                      animation: {
                          enter: 'slideInLeft'
                      },
                      views: {
                          '': {
                              templateUrl: 'templates/utilities/mySettings.html',
                              controller: 'settingController'
                          },
                          'profile@mySettings': {
                              templateUrl: 'templates/utilities/profile.html',
                              controller: 'profileController'
                          }
                      }
                  })
                  .state('info', {

                      url: '/info',
                      animation: {
                          enter: 'slideInLeft'
                      },
                      templateUrl: 'templates/utilities/info.html'
                  }).state('profile', {
                      url: '/profile',
                      templateUrl: 'templates/utilities/profile.html',
                      controller: 'profileController',
                      animation: {
                          enter: 'slideInLeft'
                      }
                  })



              /* News Module */

              .state('newsAnnouncements', {
                      url: '/news_announcements',
                      animation: {
                          enter: 'slideInLeft'
                      },
                      views: {
                          '': {
                              templateUrl: 'templates/news/news_announcements.html',
                              controller: 'newsController',
                          },
                          'profile@newsAnnouncements': {
                              templateUrl: 'templates/utilities/profile.html',
                              controller: 'profileController'
                          }
                      }

                  })
                  .state('newsDetails', {
                      url: '/newsDetails',
                      animation: {
                          enter: 'slideInLeft'
                      },
                      views: {
                          '': {
                              templateUrl: 'templates/news/newsDetails.html',
                              controller: 'newsDetailController'
                          },
                          'profile@newsDetails': {
                              templateUrl: 'templates/utilities/profile.html',
                              controller: 'profileController'
                          }
                      }
                  })

              /* Search Module */
              .state('searchResults', {
                  url: '/searchResults/',
                  animation: {
                      enter: 'slideInLeft'
                  },

                  views: {
                      '': {
                          templateUrl: 'templates/search/searchResults.html',
                          controller: 'searchPageResults'
                      },
                      'profile@searchResults': {
                          templateUrl: 'templates/utilities/profile.html',
                          controller: 'profileController'
                      }
                  }
              }).state('searchPage', {
                  url: '/searchPage',
                  animation: {
                      enter: 'slideInLeft'
                  },
                  views: {
                      '': {
                          templateUrl: 'templates/search/searchPage.html',
                          controller: 'searchPage'
                      },
                      'profile@searchPage': {
                          templateUrl: 'templates/utilities/profile.html',
                          controller: 'profileController'
                      }
                  }
              })
          }
      ])
      .run(function($rootScope, $state, $stateParams, loginModel, $http) {

          // Sends this header with any AJAX request
          $http.defaults.headers.common['Access-Control-Allow-Origin'] = '*';
          // Send this header only in post requests. Specifies you are sending a JSON object
          $http.defaults.headers.post['dataType'] = 'json'


          $rootScope.$state = $state;
          $rootScope.$stateParams = $stateParams;
          $rootScope.$on("$stateChangeSuccess", function(event, toState, toParams, fromState, fromParams) {
              // to be used for back button //won't work when page is reloaded.
              $rootScope.previousState_name = fromState.name;
              $rootScope.previousState_params = fromParams;
          });

          // //back button function called from back button's ng-click="back()"
          $rootScope.back = function() {
              $state.go($rootScope.previousState_name, $rootScope.previousState_params);
          };

          $rootScope.go = function(stateName, object) {
              $state.go(stateName, object);
          }


      });

myApp.constant("config", {
    "helplist": [{
        'question': 'What is BT Document Wizard?',
        'answer': 'BT Document Wizard is an automated web based application used for creating proactive proposals and responding to Requests For Proposals (RFPs) and Invitations To Tender (ITT). <br> The IT Service Desk does not support this application. <br> For more information see the BT Document Wizard website or for issues email <a href="sant.suite@bt.com">sant.suite@bt.com</a>.'
    }, {
        'question': 'BT Document Wizard Suite Password Information',
        'answer': 'To obtain a password reset for BT Document Wizard Suite, please email <a href="mailto:sant.suite@bt.com">sant.suite@bt.com</a>'
    }],

    "devURL" : {
        'url' : 'http://santdev.bt.com/_api/',
        'baseURL' : 'http://santdev.bt.com/_layouts/15/BT.SANT.MobileServices/',
        'announcement' : "lists/getbytitle('SANTAnnouncement')/Items",
        'profile' : "sp.userprofiles.peoplemanager/GetMyProperties/UserProfileProperties",
        'setting' : "sp.userprofiles.peoplemanager/GetMyProperties/UserProfileProperties",
        'links' : "lists/getbytitle('UsefulLinks')/Items",
        'header': '{ "Accept": "application/json; odata=verbose" }',
        'rfpCatagory' : "lists/GetByTitle('RFPCategories')/items?select=ID,Title",
        'rfpQuestion' : "lists/GetByTitle('RFP%20QA')/items?$select=RFP_x0020_CategoryId,RFPQuestion,RFPAnswers",
        'contextInfo' : "contextinfo",
        'rfpSubCatagory' : "/Lists/GetByTitle('RFP%20QA')/getitems?$select=ID,RFPQuestion,RFPAnswers",
        'rfpDelete' : "/Web/Lists(guid'805171da-341f-417e-b5b5-9e41922789ab')/Items(",
        'loginvalidate':'http://santdev.bt.com/_api/web/currentuser',
        'viewProject': "ViewProjects.aspx",
        'viewProjectProperties': "web/GetFileByServerRelativeUrl('",
        'viewProjectProperties2' :  "')/ListItemAllFields",
        "myWork" : "')/Files?$Select=Name,TimeCreated,TimeLastModified,ServerRelativeUrl",
        'search' :"http://santdev.bt.com/_layouts/15/BT.SANT.MobileServices/SearchDocument.aspx?qrytype=docname&querytxt=",
        'viewFavourite' : 'favourites.aspx?mode=view',
        'deleteFavourite' : 'favourites.aspx?mode=delete&itemid=',
        'projectType' : 'projecttype.aspx?mode=projecttype',
        'documentSubType' : 'projecttype.aspx?mode=docsubtype&doctypeid=',
        'submitcase1' : 'createproject.aspx?projecttype=',
        'documenttype':'&documenttype=',
        'newcasestep2': 'DropdownlistValues.aspx',
        'loadTask' :"Tasks.aspx",
        'case2Submit':"Web/Lists/getByTitle(\'SANT Documents\')/items('",
        'sectionNavigation' : "SectionsNavigation.aspx?templateid=",
        // 'dataEntry' : 'http://santdev.bt.com/_layouts/15/BT.SANT.MobileServices/DataEntry.aspx?mode=values&userid=607569566&documentname=Fauzi_MS_Test_2016-10-20-2&path=/SANTDocumentTypes/GS%20Proposal%20and%20Document%20Builder/Initial%20Information/Sender%20Information&folderid=9baa078f-033d-4929-b732-1bd017a4076a',
        'path' : '&path=',

        //Built Document

        'viewBuiltDocument' : 'ViewBuiltDocuments.aspx',

        //Copy parameter
        'copyProject' : 'CopyProject.aspx?userid=',
        'documentname' : '&documentname=',

        //Assign document 
        'assignuser' : 'assignuser.aspx?itemid=',
        'ownerid' : '&ownerid=',
        'assignuserid': '&assignuserid=',
        'folderId' : '&folderid=',

        //Delete the document
        'deleteproject' :'deleteproject.aspx?username=',
        'filename' :'&filename=',

        //Save the Data entry

        'dataEntry' : 'DataEntry.aspx?mode=values&userid=',

        //Submit the Data Entry

        'submitDataEntry' : 'DataEntry.aspx?mode=save&userid=',
        'dataitemguid' : '&dataitemguid=',
        'dataitemvalue' : '&dataitemvalue=',

        //Add optional save

        'addOptionalSave' : '/OptionalSections.aspx?mode=add&itemguid=',
        'userid' : '&userid=',

        //Remove Optional save
        'removeOptionalSave' : '/OptionalSections.aspx?mode=remove&itemguid=',

        //Delete task 

        'deleteTask' : 'DeleteMethod.aspx/DeleteTasks'
    },


    

    "myWorkoption": [{
        imageUrl: "resources/images/480/view_project.png",
        info: "Incomplete Project",
        detail: "Incompleted project which require your attension",
        click: "viewProject"
    }, {
        imageUrl: "resources/images/480/view_build.png",
        info: "Completed Built Document",
        detail: "Share and get the document on your completed document",
        click: "buildDocument"
    }, {
        imageUrl: "resources/images/480/view_task.png",
        info: "View Task",
        detail: "Pending task assigned on your name",
        click: "viewTask"
    }, {
        imageUrl: "resources/images/480/favorites.png",
        info: "View Favourites",
        detail: "All the favorite Document",
        click: "favoritesView"
    }],



    search_criteria: [{
        id: "1",
        name: "PDF",
        selected: true
    }, {
        id: "2",
        name: "DOCX",
        selected: false
    }, {
        id: "3",
        name: "XLS",
        selected: false
    }, {
        id: "4",
        name: "PPTX",
        selected: false
    }],
    
    "documentFormat": [{
        id: "1",
        name: "PDF",
        text: "Portable Document Format",
        image: "resources/images/480/pdfsmall_01.png"
    }, {
        id: "2",
        name: "DOCX",
        text: "Microsoft Word Document",
        image: "resources/images/480/wordsmall_01.png"

    }],

});

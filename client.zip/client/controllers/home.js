 myApp.controller('homeController', ['$scope', '$state', '$location', 'config', 'restService', 'applicationModel', 'myService', '$http',
     function($scope, $state, $location, config, restService, applicationModel, myService, $http) {
         //  $scope.doc = {};

         $scope.optionalinfo = config.option;

         $scope.link = applicationModel.getModel().links;


         $scope.newsAnnouncements = function() {

             var url = config.devURL.url + config.devURL.announcement;

             restService.getRequest(url, config.devURL.header, newsSuccess, newsFailure);
         }


         $scope.rfpCatagory = function() {
             var url = config.devURL.url + config.devURL.rfpCatagory;

             restService.getRequest(url, config.devURL.header, rfpSuccess, rfpFailure);

         }

         var rfpSuccess = function(response) {

             $http.get("./projectdata/rfpcatagory.json").then(function(response) {

                 applicationModel.addModel("rfpCatagory", response.data.d.results);
                 $state.go('rfpcatagory');

             });
         }

         var rfpFailure = function(response) {
             // $state.go('error');

             /* Still the time service occurs, we are using this redirect */

             rfpSuccess(response);

         }




         var newsSuccess = function(response) {
             $http.get("./projectdata/announcement.json").then(function(response) {

                 applicationModel.addModel("news", response.data.d.results);

                 $state.go('newsAnnouncements');


             });


         }

         var newsFailure = function(response) {
             // $state.go('error');

             newsSuccess(response);

         }


         $scope.linkService = function() {

             var url = config.devURL.url + config.devURL.links;

             restService.getRequest(url, config.devURL.header, linkSuccess, linkFailure);
         }

         var linkSuccess = function(response) {

             $http.get("./projectdata/usefullinks.json").then(function(response) {

                 var temp = {};
                 angular.forEach(response.data.d.results, function(value) {

                     if (temp[value.Category.Title] == undefined) {
                         var tempArray = [];
                         tempArray.push(value);
                         temp[value.Category.Title] = tempArray;
                     } else {
                         temp[value.Category.Title].push(value);
                     }

                 });


                 applicationModel.addModel("links", temp);

                 $state.go('usefullinks');

             });
         }

         var linkFailure = function(response) {
             // $state.go('error');

             /* Still the time service occurs, we are using this redirect */

             linkSuccess(response);
         }

         $scope.getSetting = function() {
             $state.go('mySettings');
         }

         $scope.myWork = function() {
             $state.go('myWork');
         }

     }
 ]);

 myApp.controller('HelpController', ['$scope', '$state', 'config',
     function($scope, $state, config) {
         $scope.helplist = config.helplist;
     }
 ]);

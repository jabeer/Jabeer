 myApp.controller('loginController', ['$scope', '$state', 'config', 'loginModel', 'FoundationApi', 'restService', '$http',

     function($scope, $state, config, loginModel, FoundationApi, restService, $http) {

         if (loginModel != undefined) {

             $scope.loginId = loginModel.loginId;
             $scope.password = loginModel.password;
             $scope.rememberMe = loginModel.rememberMe;

             if (!loginModel.rememberMe) {
                 $scope.loginId = "";
                 $scope.password = "";
                 $scope.rememberMe = false;

             }
         } else {
             loginModel.isFirstTime = true;
         }




         $scope.onSubmit = function() {
             // console.log(user.loginId);
             loginModel.rememberMe = $scope.rememberMe;
             loginModel.loginId = $scope.loginId;

             if ($scope.rememberMe) {
                 loginModel.password = $scope.password;
             }

             restService.getRequest(config.devURL.loginvalidate, config.devURL.header, loginSuccess, loginfailure);

         };

         var loginSuccess = function(response) {


             $http.get("./projectdata/user.json").then(function(response) {


                 var serverUser = response.data.d.LoginName.split("\\")[1];


                 if ($scope.loginId == serverUser && $scope.password == "test") {

                     if (loginModel.isFirstTime) {
                         loginModel.isFirstTime = false;
                         $state.go('loginsucess');
                     } else {
                         $state.go('home');
                     }
                 } else {
                     $state.go('loginfailure');
                 }

             });

         }

         var loginfailure = function(response) {
             // $state.go('loginfailure');
             // Time being
             loginSuccess(response);
         }

         $scope.forgotPassword = function() {
             $state.go('forgotPassword');
         };
         $scope.help = function() {
             $state.go('help');
         };
         $scope.home = function() {
             $state.go('home');
         }

         $scope.forgotPasswordSubmit = function() {
             FoundationApi.publish('assignpopModal', 'open');
         }

     }
 ]);

 /*
  * create the singleton model for make it work as the global model
  *
  */
 myApp.factory('loginModel', function() {
     return {};
 });

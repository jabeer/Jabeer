myApp.controller('createdocController', ['$scope', '$state', 'config', 'restService', 'applicationModel', '$http',

    function($scope, $state, config, restService, applicationModel, $http) {

        var url = config.devURL.baseURL + config.devURL.projectType;

        $scope.showDocumentSubType = false;

        $scope.submitEnable = true;

        $scope.submitDropdown = false;

        $scope.submitText = false;

        restService.getRequest(url, config.devURL.header, function(response) {

            $scope.projectType = {};

            $http.get("./projectdata/projectType.json").then(function(response) {

                angular.forEach(response.data, function(item) {

                    if ($scope.projectType[item.ProjectType] == undefined) {
                        $scope.projectType[item.ProjectType] = [item];
                    } else {
                        $scope.projectType[item.ProjectType].push(item);
                    }

                });

            });

        }, function(response) {

            $scope.projectType = {};

            $http.get("./projectdata/projectType.json").then(function(response) {

                angular.forEach(response.data, function(item) {

                    if ($scope.projectType[item.ProjectType] == undefined) {
                        $scope.projectType[item.ProjectType] = [item];
                    } else {
                        $scope.projectType[item.ProjectType].push(item);
                    }

                });
            });
        });


        $scope.selectProjectType = function(projectType) {

            $scope.documentType = $scope.projectType[projectType];

        }

        $scope.selectDocumentType = function(dataItemGUID) {

            var url = config.devURL.baseURL + config.devURL.documentSubType + dataItemGUID;

            restService.getRequest(url, config.devURL.header, selectDocumentTypeSuccess, selectDocumentTypeFailure);

        }

        var selectDocumentTypeSuccess = function(response) {

            $scope.showDocumentSubType = true;

            $http.get("./projectdata/documentSubType.json").then(function(response) {

                $scope.documentSubType = response.data;

            });
        }

        var selectDocumentTypeFailure = function(response) {

            // $state.go('error');
            selectDocumentTypeSuccess(response);


        }

        $scope.selectDocumentSubType = function(value) {
            $scope.submitDropdown = false;
            if (value != undefined) {
                $scope.submitDropdown = true;
            }
            enableSubmit();
        }

        $scope.nameDocument = function(name) {

            if (name != undefined && name.length > 0) {
                $scope.submitText = true;
            } else {
                $scope.submitText = false;
            }
            enableSubmit();
        }


        var enableSubmit = function() {
            if ($scope.submitText == true && $scope.submitDropdown == true) {
                $scope.submitEnable = false;
            }
        }


        $scope.submit = function() {

            var documentType = JSON.parse($scope.selected.documentType);

            var url = config.devURL.baseURL + config.devURL.submitcase1 + $scope.selected.projectType + config.devURL.documenttype + documentType.DocumentTypeName + "&documenttypeguid=" + documentType.DataItemGUID + "&projectname=" + $scope.document.name + "&documentsubtypeguid=" + $scope.selected.documentSubType + "&documenttypeversion=799";

            restService.getRequest(url, config.devURL.header, stepOneSuccess, stepOneFailure);

        }

        var stepOneFailure = function(response) {
            // $state.go('error');

            stepOneSuccess(response);
        }

        var stepOneSuccess = function(response) {
            //Data the model into the model for later processing the data

            var response = [{
                "Status": "Document Created"
            }, {
                "ID": "455"
            }];
            applicationModel.addModel("step1", response);

            $state.go('createdocument.step2');
        }
    }
]);

myApp.controller('createdocstep3Controller', ['$scope', '$state', 'config', 'applicationModel', 'restService', '$http', 'FoundationApi',
    function($scope, $state, config, applicationModel, restService, $http, FoundationApi) {


        $scope.initial = [];

        $scope.optionalInfo = [];

        $scope.showInitial = false;

        $scope.showOptional = false;

        $scope.buildbutton = false;

        $scope.removeOptional = [];

        var addOptionalCount = 0;

        var newData = {};

        var newOptionalData = {};

        var stepTwoResponse = applicationModel.getModel().step2;

        if (stepTwoResponse != undefined) {

            var userId;

            $scope.projectName = stepTwoResponse.DocumentTitle;

            $scope.documentType = stepTwoResponse.DocumentType;

            if (stepTwoResponse.UserId != "") {
                userId = stepTwoResponse.UserId;
            } else {
                userId = loginModel.loginId;
            }


            var url = config.devURL.baseURL + config.devURL.sectionNavigation +
                stepTwoResponse.DocumentTemplateGUID + "&documentid=" + stepTwoResponse.DocumentTitle + "&subdoctypeid=" + stepTwoResponse.DocumentSubType + "&userid=" + userId;


            restService.getRequest(url, config.devURL.header, function(response) {}, function(response) {



                //TODO: Need to move this Code from integrated with the Original code,

                $http.get("./projectdata/section_header.json").then(function(response) {

                    angular.forEach(response.data, function(item) {


                        if (item.Required == "True" && item.ParentDataItemGUID == "") {
                            var title = item.SectionPath.split("/");
                            item["title"] = title[title.length - 1];
                            item["show"] = true;
                            newData[item.DataItemGUID] = item;
                            $scope.showInitial = true;
                            if (item.IsSectionCompleted == "False") {
                                $scope.buildbutton = true;
                            }
                        } else if (item.Required == "True" && item.ParentDataItemGUID != "") {
                            if (newData[item.ParentDataItemGUID].child == undefined) {
                                var title = item.SectionPath.split("/");
                                item["title"] = title[title.length - 1];
                                newData[item.ParentDataItemGUID].child = [item];
                            } else {
                                var title = item.SectionPath.split("/");
                                item["title"] = title[title.length - 1];
                                newData[item.ParentDataItemGUID].child.push(item);
                            }
                            if (item.IsSectionCompleted == "False") {
                                newData[item.ParentDataItemGUID].IsSectionCompleted = "False";
                                $scope.buildbutton = false;

                            }

                        } else if (item.OptionalSectionSelected == "True" && item.ParentDataItemGUID == "") {
                            var title = item.SectionPath.split("/");
                            item["title"] = title[title.length - 1];
                            item["show"] = true;
                            newOptionalData[item.DataItemGUID] = item;
                            $scope.showOptional = true;
                            

                        } else if (item.OptionalSectionSelected == "True" && item.ParentDataItemGUID != "") {
                            if (newOptionalData[item.ParentDataItemGUID].child == undefined) {
                                newOptionalData[item.ParentDataItemGUID].child = [item];
                            } else {
                                newOptionalData[item.ParentDataItemGUID].child.push(item);
                            }
                        }


                    });
                });


                $scope.initial = newData;
                $scope.optionalInfo = newOptionalData;


            });


        }

        /*
         * Function to show/Hide item in accordion
         */
        $scope.isParent = function(parentItem) {


            if ($scope.initial[parentItem].child != undefined) {

                if ($scope.initial[parentItem].added == undefined || $scope.initial[parentItem].added == false) {
                    $scope.initial[parentItem]["added"] = true;

                    angular.forEach($scope.initial[parentItem].child, function(childValue) {

                        childValue["show"] = true;

                        $scope.initial[childValue.DataItemGUID] = childValue;
                    });

                } else {
                    $scope.initial[parentItem].added = false;
                    angular.forEach($scope.initial, function(childValue) {
                        if (childValue.ParentDataItemGUID == parentItem) {
                            delete $scope.initial[childValue.DataItemGUID];
                        }
                    });

                }

            }

            sortItem();
        }

        $scope.OptionalSelect = function(item) {

            var temp = {};

            if (applicationModel.getModel().optional == undefined) {
                temp[item.DataItemGUID] = item;

            } else {

                temp = applicationModel.getModel().optional;
                if (temp[item.DataItemGUID] == undefined) {
                    temp[item.DataItemGUID] = item;
                } else {
                    delete temp[item.DataItemGUID];
                    $scope.removeOptional.push(item);
                }

            }
            applicationModel.addModel("optional", temp);

        }


        /*
         * Sort the Initial items
         */
        var sortItem = function() {
            //sorting is pending
        }



        var addOptionalSaveSuccess = function(response) {
            // addOptionalCount--;
            if (addOptionalCount == 0) {
                var stepResponse = [];
                angular.forEach($scope.initial, function(item) {
                    if (item.IsSectionCompleted != "True") {
                        stepResponse.push(item);
                    }

                });

                applicationModel.addModel("step3", stepResponse);

                $state.go('doccreated');
            }

        }

        var addOptionalSaveFailure = function(response) {

                addOptionalCount--;
                if (addOptionalCount == 0) {
                    // $state.go('error');
                    addOptionalSaveSuccess(response);
                }
            }
            /*
             * Submit/Next button function
             */

        var removeOptionalSaveSuccess = function(response) {

        }

        var removeOptionalSaveFailure = function(response) {

        }

        $scope.build = function() {
            $state.go('buildDocumentreview');
        }

        $scope.next = function() {

            if ($scope.removeOptional != undefined && applicationModel.getModel().step2 != undefined) {
                angular.forEach($scope.removeOptional, function(key, value) {

                    var url = config.devURL.baseURL + config.devURL.removeOptionalSave + value + config.devURL.documentname + applicationModel.getModel().step2.DocumentTitle + config.devURL.userid + applicationModel.getModel().step2.UserId;

                    restService.getRequest(url, config.devURL.header, removeOptionalSaveSuccess, removeOptionalSaveFailure);

                });

            }

            if (applicationModel.getModel().step2 != undefined && applicationModel.getModel().optional != undefined) {

                angular.forEach(applicationModel.getModel().optional, function(key, value) {

                    addOptionalCount++;

                    var url = config.devURL.baseURL + config.devURL.addOptionalSave + value + config.devURL.documentname + applicationModel.getModel().step2.DocumentTitle + config.devURL.userid + applicationModel.getModel().step2.UserId;

                    restService.getRequest(url, config.devURL.header, addOptionalSaveSuccess, addOptionalSaveFailure);

                });
            } else {

                var stepResponse = [];

                angular.forEach($scope.initial, function(item) {
                    stepResponse.push(item);
                });

                applicationModel.addModel("step3", stepResponse);

                $state.go('doccreated');

            }
        }

    }
]);

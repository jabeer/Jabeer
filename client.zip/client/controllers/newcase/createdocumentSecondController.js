myApp.controller('createdocumentSecondController', ['$scope', '$state', 'config', 'restService', 'applicationModel', '$http',

    function($scope, $state, config, restService, applicationModel, $http) {


        var stepOneResponse = applicationModel.getModel().step1;

        if (stepOneResponse == undefined) {
            $state.go('createdocument.step1');
        }

        var url = config.devURL.baseURL + config.devURL.newcasestep2;

        $scope.case2Data = {};


        restService.getRequest(url, config.devURL.header, function(response) {

                angular.forEach(response.data, function(item) {

                    if ($scope.case2Data[item.DropdownListName] == undefined) {
                        if (item.DisplayText != "N/A") {
                            $scope.case2Data[item.DropdownListName] = [item];
                        }
                    } else {
                        if (item.DisplayText != "N/A") {
                            $scope.case2Data[item.DropdownListName].push(item);
                        }

                    }

                });

                $scope.teamName = $scope.case2Data.TeamName;
                $scope.hideTeamName = false;
                if ($scope.teamName == undefined) {
                    $scope.hideTeamName = true;
                }

                $scope.opportunityStatus = $scope.case2Data.OpportunityStatus;
                $scope.hideOpportunity = false;
                if ($scope.opportunityStatus == undefined) {
                    $scope.hideOpportunity = true;
                }

                $scope.proposalStatus = $scope.case2Data.ProposalStatus;
                $scope.hideProposalStatus = false;
                if ($scope.proposalStatus == undefined) {
                    $scope.hideProposalStatus = true;
                }

                $scope.documentValue = $scope.case2Data.DocumentValue;
                $scope.hideDocumentValue = false;
                if ($scope.documentValue == undefined) {
                    $scope.hideDocumentValue = true;
                }

            },
            function(response) {

                $http.get("./projectdata/step2.json").then(function(response) {

                    angular.forEach(response.data, function(item) {

                        if ($scope.case2Data[item.DropdownListName] == undefined) {
                            if (item.DisplayText != "N/A") {
                                $scope.case2Data[item.DropdownListName] = [item];
                            }
                        } else {
                            if (item.DisplayText != "N/A") {
                                $scope.case2Data[item.DropdownListName].push(item);
                            }

                        }

                    });

                    $scope.teamName = $scope.case2Data.TeamName;
                    $scope.hideTeamName = false;
                    if ($scope.teamName == undefined) {
                        $scope.hideTeamName = true;
                    }

                    $scope.opportunityStatus = $scope.case2Data.OpportunityStatus;
                    $scope.hideOpportunity = false;
                    if ($scope.opportunityStatus == undefined) {
                        $scope.hideOpportunity = true;
                    }

                    $scope.proposalStatus = $scope.case2Data.ProposalStatus;
                    $scope.hideProposalStatus = false;
                    if ($scope.proposalStatus == undefined) {
                        $scope.hideProposalStatus = true;
                    }

                    $scope.documentValue = $scope.case2Data.DocumentValue;
                    $scope.hideDocumentValue = false;
                    if ($scope.documentValue == undefined) {
                        $scope.hideDocumentValue = true;
                    }

                });


            });

        var stepDataSuccess = function(response) {

            var stepTwoResponse = {};

            $http.get("./projectdata/step2Response.json").then(function(response) {

                stepTwoResponse = response.data.d;

            });

            applicationModel.addModel("step2", stepTwoResponse);

            $state.go('createdocument.step3');
        }


        var stepDataFailure = function(response) {
            // $state.go('error');

            stepDataSuccess(response);
        }

        $scope.submit = function() {


            var url = config.devURL.url + config.devURL.contextInfo;

            restService.postRequest(url, config.devURL.header, null, contextSuccess, contextFailure);

        }

        var contextFailure = function(response) {
            // $state.go('error');
            contextSuccess(response);
        }


        var contextSuccess = function(response) {

            var formDigest, itemdata;

            $http.get("./projectdata/context.json").then(function(response) {

                formDigest = response.data.d.GetContextWebInformation.FormDigestValue;

            });

            var url = config.devURL.url + config.devURL.case2Submit + stepOneResponse[1].ID + "')";

            var header = {
                'Accept': 'application/json;odata=verbose',
                'X-RequestDigest': formDigest,
                'X-HTTP-Method': 'MERGE',
                'If-Match': '*'
            };

            if ($scope.selected != undefined) {
                itemdata = {
                    __metadata: { 'type': 'SP.Data.SANTDocumentsItem' },
                    Comments: $scope.selected.comment,
                    TeamName: $scope.selected.teamName,
                    OpportunityStatus: $scope.selected.opportunity,
                    ProposalStatus: $scope.selected.proposal,
                    DocumentSubmissionDate0: $scope.submitDate,
                    Value: 'value 1',
                    CloseDate0: $scope.closeDate,
                    CloseProbability: $scope.selected.documentValue
                };

            } else {
                itemdata = {
                    __metadata: { 'type': 'SP.Data.SANTDocumentsItem' },
                    DocumentSubmissionDate0: $scope.submitDate,
                    Value: 'value 1',
                    CloseDate0: $scope.closeDate,
                };

            }

            var data = JSON.stringify(itemdata);

            restService.postRequest(url, header, data, stepDataSuccess, stepDataFailure);

        }

    }

]);
myApp.controller('docCreated', ['$scope', '$state', 'config', 'applicationModel', 'restService', '$http', '$sce', 'GeneratedField',
    function($scope, $state, config, applicationModel, restService, $http, $sce, GeneratedField) {

        $scope.tab = [];

        if (applicationModel.getModel().step3 != undefined) {

            angular.forEach(applicationModel.getModel().step3, function(value, key) {

                if (value.child != undefined) {

                    angular.forEach(value.child, function(childValue) {

                        $scope.tab.push(childValue);
                    });

                } else {

                    $scope.tab.push(value);

                }
            });

            angular.forEach(applicationModel.getModel().optional, function(value, key) {

                if (value.child != undefined) {

                    angular.forEach(value.child, function(childValue) {

                        $scope.tab.push(childValue);
                    });

                } else {

                    $scope.tab.push(value);

                }
            });

            $scope.currentIndex = 0;

            $scope.title = $scope.tab[$scope.currentIndex].title;

            $scope.hideNext = false;

        }

        $scope.CancelBuiltService = function() {
            $scope.back();
        }


        $scope.saveItem = function() {

            if ($scope.myForm.$dirty) {

                var saveItems = [];

                var step2 = applicationModel.getModel().step2;

                angular.forEach($scope.user, function(value, key) {
                    angular.forEach(applicationModel.getModel().dynamicData, function(dynamicValue) {
                        if (dynamicValue.DocumentFieldRef == key) {
                            dynamicValue.value = value;
                            saveItems.push(dynamicValue);
                        }
                    })

                });

                angular.forEach(saveItems, function(item) {

                    if (step2 != undefined) {

                        var url = config.devURL.baseURL + config.devURL.submitDataEntry + step2.UserId + config.devURL.documentname + step2.DocumentTitle + config.devURL.dataitemguid + item.DataItemGUID + config.devURL.dataitemvalue + item.value;

                        restService.getRequest(url, config.devURL.header, saveItemSuccess, saveItemFailure);

                    }
                });
            }

        }

        var saveItemFailure = function(response) {
            console.log('inside the Success of Save Item Failure');
        }

        var saveItemSuccess = function(response) {
            console.log('inside the Success of Save Item Success');
        }


        $scope.nextItem = function() {

            if ($scope.tab.length - 1 == $scope.currentIndex + 1) {
                $scope.hideNext = true;
            }

            $scope.currentIndex++;
            $scope.title = $scope.tab[$scope.currentIndex].title;
            loadDynamicData();
        }

        $scope.previousItem = function() {
            $scope.hideNext = false;
            $scope.currentIndex--;
            $scope.title = $scope.tab[$scope.currentIndex].title;
            loadDynamicData();
        }

        var dynamicDataSuccess = function(response) {

            var loadFile = $scope.title;

            if (loadFile == "Sender Information") {
                loadFile = "/projectdata/senderInfo.json";
            } else if (loadFile == "Customer Information") {
                loadFile = "/projectdata/customerInfo.json";
            } else if (loadFile == "Document Title") {
                loadFile = "/projectdata/docTitle.json";
            } else if (loadFile == "Submission Date") {
                loadFile = "/projectdata/submissionDate.json";
            } else if (loadFile == "Opportunity ID") {
                loadFile = "/projectdata/oppurtunityID.json";
            } else if (loadFile == "Disclaimer Statements") {
                loadFile = "/projectdata/disclaimerStat.json";
            }

            $http.get(loadFile).then(function(response) {

                applicationModel.addModel('dynamicData', response.data);

                var content = GeneratedField.generateField(response);

                $scope.content = $sce.trustAsHtml(content);

            });
        }

        var dynamicDataFailure = function(response) {

            dynamicDataSuccess(response);
        }

        var loadDynamicData = function() {

            var step2 = applicationModel.getModel().step2;

            if (step2 != undefined) {
                var dataEntrycheck = $scope.tab[$scope.currentIndex].PageUrl.split("?")[0].split("/")[2].split(".")[0];

                if (dataEntrycheck == "dataentry") {

                    var url = config.devURL.baseURL + config.devURL.dataEntry + step2.UserId + config.devURL.documentname + step2.DocumentTitle

                        +config.devURL.path + $scope.tab[$scope.currentIndex].SectionPath + config.devURL.folderId;

                    restService.getRequest(url, config.devURL.header, dynamicDataSuccess, dynamicDataFailure);

                } else {

                    var url = config.devURL.baseURL;

                    // config.devURL.dataEntry + step2.UserId + config.devURL.documentname + step2.DocumentTitle

                    //     +config.devURL.path + $scope.tab[$scope.currentIndex].SectionPath + config.devURL.folderId;
                    
                    restService.getRequest(url, config.devURL.header, dynamicDataSuccess, dynamicDataFailure);
                }
            }
        }
        loadDynamicData();
    }
]);

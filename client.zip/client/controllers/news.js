myApp.controller('newsController', ['$scope', '$state', 'applicationModel',
    function($scope, $state, applicationModel) {

        $scope.newslist = applicationModel.getModel().news;

        $scope.LoadDetails = function(item) {

            applicationModel.addModel('newsDetail', item);

            $state.go('newsDetails');
        }


    }
]);


myApp.controller('newsDetailController', ['$scope', '$state', 'applicationModel',
    function($scope, $state, applicationModel) {

        $scope.item = applicationModel.getModel().newsDetail;

    }
]);

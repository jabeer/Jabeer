myApp.controller('rfpQuesAnsController', ['$scope', '$state', 'applicationModel',
    function($scope, $state, applicationModel) {


        $scope.rfpQuestionDetails = applicationModel.getModel().rfpDetailResult;

    }
]);

/*
 * Controller : for displaying the applciation catagory
 */
myApp.controller('rfpCatagoryController', ['$scope', '$state', 'applicationModel', 'restService', 'config', '$http',
    function($scope, $state, applicationModel, restService, config, $http) {

        $scope.rfpCatagory = applicationModel.getModel().rfpCatagory;

        var selectedId;

        $scope.showSubItems = function(catagoryId) {

            var url = config.devURL.url + config.devURL.contextInfo;

            selectedId = catagoryId;

            restService.postRequest(url, config.devURL.header, null, contextSuccess, contextFailure);

        }


        var contextSuccess = function(response) {

            var formDigest;

            $http.get("./projectdata/context.json").then(function(response) {

                formDigest = response.data.d.GetContextWebInformation.FormDigestValue;

            });

            var url = config.devURL.url + config.devURL.rfpSubCatagory;

            var header = {
                "accept": "application/json;odata=verbose",
                "content-type": "application/json;odata=verbose",
                "X-RequestDigest": formDigest
            };


            var viewXML = "<View Scope='RecursiveAll'><Query>" +
                "<Where><Eq><FieldRef Name='RFP_x0020_Category' LookupId='true'/><Value Type='Lookup'>" + selectedId + "</Value></Eq></Where>" +
                "</Query></View>";

            var camlQuery = {
                'query': {
                    '__metadata': { 'type': 'SP.CamlQuery' },
                    'ViewXml': viewXML
                }
            };

            var body = JSON.stringify(camlQuery);

            restService.postRequest(url, header, body, rfpSubCatagorySucess, rfpSubCatagoryFailure);
        }

        var rfpSubCatagorySucess = function(response) {

            $http.get("./projectdata/rfpSubCatagory.json").then(function(response) {

                applicationModel.addModel("rfpSubCatagory", response.data.d.results);

                $state.go('rfpQuestions');
            });

        }

        var rfpSubCatagoryFailure = function(response) {
            // $state.go('error');
            rfpSubCatagorySucess(response);
        }

        var contextFailure = function(response) {
            // $state.go('error');
            contextSuccess(response);
        }

    }
]);

myApp.controller('rfpQuestionController', ['$scope', '$state', 'config', 'restService', 'applicationModel', 'FoundationApi',
    function($scope, $state, config, restService, applicationModel, FoundationApi) {

        $scope.count = 0;

        $scope.rfpQuestions = [];

        $scope.rfpQuestionList = applicationModel.getModel().rfpSubCatagory;


        var pushData = function(item) {

            var temp = $scope.rfpQuestions.indexOf(item.Id);

            if (temp == -1) {
                $scope.rfpQuestions[item.Id] = item;
                $scope.count++;
            } else {
                $scope.rfpQuestions.splice(item.Id, 1);;
                $scope.count--;
            }

        }

        $scope.confirmDelete = function() {



            for (var i = $scope.rfpQuestionList.length - 1; i >= 0; i--) {
                if ($scope.rfpQuestions != undefined) {
                    angular.forEach($scope.rfpQuestions, function(deletedTask, value) {
                        if ($scope.rfpQuestionList != undefined) {


                            if (deletedTask.Id == $scope.rfpQuestionList[i].Id) {

                                var url = config.devURL.url + config.devURL.rfpDelete + deletedTask + ')';
                                var header = {
                                    "accept": "application/json;odata=verbose",
                                    "content-type": "application/json;odata=verbose",
                                    // "X-RequestDigest": formDigest
                                    "X-Http-Method": "DELETE",
                                    "If-Match": $scope.rfpQuestionList[i].__metadata.etag
                                };

                                restService.postRequest(url, header, null, $scope.confirmDeleteSuccess, $scope.confirmDeleteFailure);
                                $scope.rfpQuestionList.splice(i, 1);
                            }
                        }

                    });
                }
            }


        }

        $scope.confirmDeleteSuccess = function(response) {

            $scope.count = $scope.count - 1;


            if ($scope.count == 0) {
                $scope.rfpQuestions = [];

                FoundationApi.publish('deleteTaskModel', 'close');
            }
        }

        $scope.confirmDeleteFailure = function(response) {
            // $state.go('error');
            $scope.confirmDeleteSuccess(response);
        }

        $scope.checkBoxChecked = function(item) {
            pushData(item);

        }



        $scope.rfpQuestionDetail = function(items) {

            applicationModel.addModel("rfpDetailResult", items);

            $state.go('rfpQuestionDetail');
        }

    }
]);
myApp.controller('createquestionsController', ['$scope', '$state', 'FoundationApi', 'config', 'restService',
    function($scope, $state, FoundationApi, config, restService) {
        $scope.rfp = {};
        $scope.rfp.submissionDate = new Date();
        $scope.createQuestions = function(rfp) {

            $scope.rfp = rfp;

            var url = config.devURL.url;

            restService.getRequest(url, config.devURL.header, rfpSuccess, rfpFailure);

            // $state.go('quesAnslist');
        }

        var rfpSuccess = function(response) {
            console.log('suceess');
        }

        var rfpFailure = function(response) {
            // $state.go('error');
            rfpSuccess(response);
        }

        $scope.getpeopleData = function(peopleData) {
            $scope.rfp.peopleDataList = peopleData;
            FoundationApi.publish('assignpopModal', 'close');
        }

        $scope.getpeopleData2 = function(peopleData) {
            $scope.rfp.peopleDataList2 = peopleData;
            FoundationApi.publish('assignpopModal2', 'close');
        }
    }
]);

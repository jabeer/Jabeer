myApp.controller('searchPage', ['$scope', '$state', 'config', 'restService','$http','applicationModel',
    function($scope, $state, config, restService,$http,applicationModel) {

        $scope.fileExtension = config.search_criteria;

        $scope.searchSubmit = function() {

                var url = config.devURL.search + $scope.search_input;

                restService.getRequest(url, config.devURL.header, $scope.searchSuccess, $scope.successFailure);


            }
            //Clearing the input's
        $scope.clearSearchbox = function() {
            $scope.search_input = "";
            angular.forEach($scope.fileExtension, function(extension_id) {
                extension_id.selected = false;
            });
        }

        $scope.searchSuccess = function(response) {


            // angular.forEach($scope.fileExtension, function(value, key) {
            //     if (value.selected == true) {
            //         $scope.selectedKey += value.name;
            //     }
            // });


            $http.get("./projectdata/search.json").then(function(response) {

                applicationModel.addModel("searchResult", response.data);

                $state.go('searchResults');

            });


            // var viewFavoriteResponse = { "viewFavorite": config.viewProjectListData };

            // applicationModel.addModel(viewFavoriteResponse);


        }

        $scope.successFailure = function(response) {
            /* Temporary Disabled due to service unavailblity */

            // $state.go('error');
            $scope.searchSuccess(response);
        }

    }
]);

myApp.controller('searchPageResults', ['$scope', '$state', 'myService', 'applicationModel', 'config',
    function($scope, $state, myService, applicationModel, config) {

        $scope.searchData = applicationModel.getModel().searchResult;

    }
]);

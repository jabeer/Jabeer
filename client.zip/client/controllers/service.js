 myApp.service('restService', ['$http', 'cfpLoadingBar',
     function($http, cfpLoadingBar) {

         this.getRequest = function(url, header, successCallback, failureCallback) {


             console.log(url);
             console.log(header);

             var url = "http://www.mocky.io/";

             var headers = {
                 'Access-Control-Allow-Origin': '*',
                 'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT',
                 'Content-Type': 'application/json',
                 'Accept': 'application/json'
             };

             return $http({
                 method: "POST",
                 // headers: headers,
                 url: url,
                 // data: { "email": "my@email.com", "password": "secret" }
             }).success(function(result) {
                 console.log("Auth.signin.success!")
                 console.log(result);
             }).error(function(data, status, headers, config) {
                 console.log("Auth.signin.error!")
                 console.log(data);
                 console.log(status);
                 console.log(headers);
                 console.log(config);
             });

             // this.progressBarStart();
             // var self = this;
             // debugger;
             // $http({
             //     method: 'POST',
             //     url: url,
             //     headers: {
             //         'Content-Type': 'application/x-www-form-urlencoded',
             //         'Access-Control-Allow-Origin':'*',
             //         'Access-Control-Allow-Methods' : 'DELETE, HEAD, GET, OPTIONS, POST, PUT',
             //         'Access-Control-Allow-Headers' : 'Content-Type, Content-Range, Content-Disposition, Content-Description`',
             //         'Access-Control-Max-Age':'1728000'
             //     },
             //     timeout: 2000,
             // }).then(function success(response) {
             //     self.progressComplete();
             //     console.log('sucess');
             //     // successCallback(response);
             // }, function error(response) {
             //     self.progressComplete();
             //     console.log('failure');
             //     // failureCallback(response);
             // });


         };


         this.postRequest = function(url, header, body, successCallback, failureCallback) {
             console.log(url);
             console.log(header);
             console.log(body);
             this.progressBarStart();
             var self = this;
             $http({
                 method: 'POST',
                 url: url,
                 data: body,
                 headers: header,
                 timeout: 2000,
             }).then(function success(response) {
                 self.progressComplete();
                 successCallback(response);
             }, function error(response) {
                 self.progressComplete();
                 failureCallback(response);
             });
         }

         this.progressBarStart = function() {
             cfpLoadingBar.start();
             this.toggleProgressScreen();
         }

         this.progressComplete = function() {
             cfpLoadingBar.complete();
             this.toggleProgressScreen();
         }

         this.toggleProgressScreen = function() {
             var progressbar = angular.element(document.querySelector('#progressBarContainer'));
             if (progressbar[0].style.display == "block") {
                 progressbar[0].style.display = "none";
             } else {
                 progressbar[0].style.display = "block";
             }

         };




     }
 ]);

 myApp.service('applicationModel', function() {
     var modelList = {};



     var addModel = function(key, newModel) {
         modelList[key] = newModel;
     };

     var getModel = function() {
         return modelList;
     };

     var init = function() {
         modelList = {};
     }

     return {
         addModel: addModel,
         getModel: getModel,
         init: init

     };

 });


 myApp.service('GeneratedField', function() {

     var getField = function(response) {

         var content = '<form ng-model="user" vmsg-form name="myForm" ><br/>';

         angular.forEach(response.data, function(data) {

             if (data.DataType == "Text") {

                 content += '<div class="customTextBox" id="' + data.DataItemGUID + '"><label>';

                 if (data.Required == "True") {
                     content += data.Label + ' <span style="color:red;">*</span> </label><input ng-model="user.' + data.DocumentFieldRef + '" type="text"';
                 } else {
                     content += data.Label + '</label><input ng-model="user.' + data.DocumentFieldRef + '" type="text"';
                 }

                 if (data.DefaultValue != "") {
                     content += 'value=' + data.DefaultValue;
                 }

                 if (data.Required == "True") {
                     content += ' vmsg required';
                 }

                 content += '></div>';

             } else if (data.DataType == "Numeric") {

                 content += '<div class="customTextBox"><label>';

                 if (data.Required == "True") {
                     content += data.Label + ' <span style="color:red;">*</span> </label><input ng-model="user.' + data.DocumentFieldRef + '" type="text"';
                 } else {
                     content += data.Label + '</label><input ng-model="user.' + data.DocumentFieldRef + '" type="number"';
                 }

                 if (data.DefaultValue != "") {
                     content += 'value=' + data.DefaultValue;
                 }

                 if (data.Required == "True") {
                     content += ' vmsg required';
                 }

                 content += '></div>';

             } else if (data.DataType == "Label" || data.DataType == "Static Field") {

                 content += '<div class="customTextBox"><h3>' + data.Label + '</h3></div>';

             } else if (data.DataType == "Date") {

                 content += '<div class="customTextBox"><label>';

                 if (data.Required == "True") {
                     content += data.Label + ' <span style="color:red;">*</span> </label><quick-datepicker ng-model="user.' + data.DocumentFieldRef + '" disable-timepicker=true"';
                 } else {
                     content += data.Label + '</label><quick-datepicker ng-model="user.' + data.DocumentFieldRef + '" disable-timepicker=true ';
                 }

                 if (data.DefaultValue != "") {
                     content += 'value=' + data.DefaultValue;
                 }

                 if (data.Required == "True") {
                     content += ' vmsg required';
                 }

                 content += '></quick-datepicker></div>';

             } else if (data.DataType == "image") {

                 content += '<div class="customTextBox"><label>';

                 if (data.Required == "True") {
                     content += data.Label + ' <span style="color:red;">*</span> </label><input type="text"';
                 } else {
                     content += data.Label + '</label><img ';
                 }

                 if (data.DefaultValue != "") {
                     content += 'src=' + data.DefaultValue;
                 }

                 if (data.Required == "True") {
                     content += ' vmsg required';
                 }

                 content += '></img></div>';

             } else if (data.DataType == "Spacer") {

                 content += '<div class="customTextBox"><br><br></div>';

             } else if (data.DataType == "DropDown") {

                 content += '<div class="customTextBox"><label>' + data.Label + '</label><select>';

                 if (data.Required != "True") {

                     content += '<option>Select</option>';

                 }

                 angular.forEach(data.ListOfValues.split("\n"), function(value) {

                     if (value != '') {

                         content += '<option>' + value + '</option>';
                     }

                 });

                 content += '</select></div>';

             } else if (data.DataType == "Multi Lines of Text") {

                 content += '<div class="customTextBox"><label>';

                 if (data.Required == "True") {

                     content += data.Label + ' <span style="color:red;">*</span> </label><textarea col="7" ng-model="user.' + data.DocumentFieldRef + '"';

                 } else {

                     content += data.Label + '</label><textarea col="7" ng-model="user.' + data.DocumentFieldRef + '"';

                 }

                 if (data.DefaultValue != "") {

                     content += 'value=' + data.DefaultValue;

                 }

                 if (data.Required == "True") {

                     content += ' vmsg required';

                 }

                 content += '></textarea></div>';
             }

         });

         content += '<div style="padding-left: 24px; padding-right: 24px; "><button class="createdoc-buttonleft" type="submit" ng-click="saveItem();"><span class="state">Save</span></button><button class="createdoc-buttonright" ng-click="CancelBuiltService();"><span class="state">Cancel</span></button></div></form>';

         return content;
     };

     return {
         generateField: getField,

     };

 });


 myApp.directive('compileTemplate', function($compile, $parse) {
     return {
         link: function(scope, element, attr) {
             var parsed = $parse(attr.ngBindHtml);

             function getStringValue() {
                 return (parsed(scope) || '').toString();
             }

             //Recompile if the template changes
             scope.$watch(getStringValue, function() {
                 $compile(element, null, -9999)(scope); //The -9999 makes it skip directives so that we do not recompile ourselves
             });
         }
     }
 });

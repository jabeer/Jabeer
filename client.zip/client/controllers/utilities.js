myApp.controller('settingController', ['$scope', '$state', 'applicationModel', 'config', 'restService', '$http',
    function($scope, $state, applicationModel, config, restService, $http) {
        if (applicationModel.getModel().settings != undefined) {

            $scope.settings = applicationModel.getModel().settings;

        } else {
            var url = config.devURL.url + config.devURL.setting;

            restService.getRequest(url, config.devURL.header, function(response) {
                $http.get("./projectdata/profile.json").then(function(response) {
                    applicationModel.addModel("settings", response.data.d.UserProfileProperties.results);



                });

            }, function(response) {

                $http.get("./projectdata/profile.json").then(function(response) {

                    applicationModel.addModel("settings", response.data.d.UserProfileProperties.results);

                    $scope.settings = response.data.d.UserProfileProperties.results;


                });

            });

        }


    }
]);

myApp.controller('profileController', ['$scope', '$state', 'config', 'loginModel', 'applicationModel', 'restService', '$http',
    function($scope, $state, config, loginModel, applicationModel, restService, $http) {



        var getProfileData = function(response) {
            var temp = {};
            angular.forEach(response, function(value, key) {
                temp[value.Key] = value.Value;
            });

            return temp;
        }



        if (applicationModel.getModel().settings != undefined) {

            $scope.profile = getProfileData(applicationModel.getModel().settings);

        } else {

            var url = config.devURL.url + config.devURL.setting;

            restService.getRequest(url, config.devURL.header, function(response) {

                $http.get("./projectdata/profile.json").then(function(response) {

                    applicationModel.addModel("settings", response.data.d.UserProfileProperties.results);

                    $scope.profile = getProfileData(response.data.d.UserProfileProperties.results);

                });

            }, function(response) {

                $http.get("./projectdata/profile.json").then(function(response) {

                    applicationModel.addModel("settings", response.data.d.UserProfileProperties.results);

                    $scope.profile = getProfileData(response.data.d.UserProfileProperties.results);

                });

            });

        }


        $scope.signOut = function() {

            applicationModel.init();

            if (loginModel.rememberMe) {

                $state.go('existinguser');

            } else {

                $state.go('login');

            }

        }


    }
]);


myApp.filter('taskFilter', function() {
    return function(item) {
        if (item != undefined) {
            if (item.status != "completed") {
                return item;
            }
        }
        return item;
    }
});



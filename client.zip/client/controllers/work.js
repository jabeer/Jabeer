/*
 * MyWork Controller
 */
myApp.controller('myWorkController', ['$scope', '$state', 'config', 'restService', 'applicationModel', 'loginModel', '$http',
    function($scope, $state, config, restService, applicationModel, loginModel, $http) {
        $scope.myWorkoption = config.myWorkoption;

        $scope.getData = function(workType) {

            switch (workType) {
                case "viewProject":
                    loadProjectData();
                    break;
                case "buildDocument":
                    loadBuiltDocument();
                    break;
                case "favoritesView":
                    loadFavorite();
                    break;
                case "viewTask":
                    loadTask();
                    break;

                default:

                    break;
            }

        }

        var loadFavorite = function() {
            var url = config.devURL.baseURL + config.devURL.viewFavourite;


            restService.getRequest(url, config.devURL.header, viewFavoriteSuccess, viewFavoriteFailure);

        }

        var viewFavoriteSuccess = function(response) {

            $http.get("./projectdata/viewFav.json").then(function(response) {


                for (var i = 0; i < response.data.length; i++) {
                    var path = response.data[i].Path.split('.');
                    if (path[1] === "docx") {
                        response.data[i].file_image = 'resources/images/480/wordsmall_01.png';
                        response.data[i].file_type = "Docx";
                    } else if (path[1] === "pdf") {
                        response.data[i].file_image = 'resources/images/480/pdfsmall_01.png';
                        response.data[i].file_type = "PDF";
                    }
                }

                applicationModel.addModel("viewFavorite", response.data);
                $state.go('favoritesView');

            });



        }

        var viewFavoriteFailure = function(response) {
            /* Temporary Disabled due to service unavailblity */

            // $state.go('error');
            viewFavoriteSuccess(response);
        }

        var loadTask = function() {
            var url = config.devURL.baseURL + config.devURL.loadTask;

            restService.getRequest(url, config.devURL.header, viewTaskSuccess, viewTaskFailure);

        }

        var viewTaskSuccess = function(response) {


            $http.get("./projectdata/viewtask.json").then(function(response) {
                applicationModel.addModel("viewTask", response.data);

                $state.go('viewTask');
            });


        }

        var viewTaskFailure = function(response) {
            /* Temporary Disabled due to service unavailblity */

            // $state.go('error');
            viewTaskSuccess(response);
        }

        var loadBuiltDocument = function() {

            var url = config.devURL.baseURL + config.devURL.viewBuiltDocument;

            restService.getRequest(url, config.devURL.header, viewBuiltSuccess, viewBuiltFailure);
        }

        var viewBuiltSuccess = function(response) {

            $http.get("./projectdata/getDocument.json").then(function(response) {

                applicationModel.addModel("builtDocument", response.data);

                $state.go('buildDocument');

            });

        }

        var viewBuiltFailure = function(response) {
            /* Temporary Disabled due to service unavailblity */

            // $state.go('error');
            viewBuiltSuccess(response);
        }



        var loadProjectData = function() {

            var url = config.devURL.baseURL + config.devURL.viewProject;

            restService.getRequest(url, config.header, viewProjectSuccess, viewProjectFailure);
        }

        var viewProjectSuccess = function(response) {


            $http.get("./projectdata/getProject.json").then(function(response) {

                applicationModel.addModel("viewProject", response.data);

                $state.go('viewProjects');

            });


        }

        var viewProjectFailure = function(response) {
            /* Temporary Disabled due to service unavailblity */

            // $state.go('error');
            viewProjectSuccess(response);
        }


        $scope.project = function() {
            // $state.go('loginfailure');
            $state.go('viewProjects');
        }
    }
]);

/*
 * View project Detail Controller
 */
myApp.controller('viewProjectDetailController', ['$scope', '$state', 'config', '$stateParams', 'restService', '$http',
    function($scope, $state, config, $stateParams, restService, $http) {

        var url = config.devURL.url + config.devURL.viewProjectProperties + $stateParams.index + config.devURL.viewProjectProperties2;

        restService.getRequest(url, config.devURL.header, function(response) {

            $http.get("./projectdata/project_properties.json").then(function(response) {

                $scope.item = response.data.d;

            });

        }, function(response) {

            $http.get("./projectdata/project_properties.json").then(function(response) {

                // $scope.titleDocs = config.ProjectDocumenttitle;

                $scope.item = response.data.d;

            });

        });
    }
]);
myApp.controller('buildDocumentController', ['$scope', '$state', 'applicationModel', 'FoundationApi',
    function($scope, $state, applicationModel, FoundationApi) {

        $scope.projectDetailsList = applicationModel.getModel().builtDocument;

        $scope.count = 0;

        $scope.tempDocument = [];


        $scope.LoadProjectDetails = function(url) {
            window.open(url);
        }

        $scope.selectItem = function(id) {
            pushData(id);
            $scope.count = $scope.tempDocument.length;
        }

        var pushData = function(id) {
            var temp = $scope.tempDocument.indexOf(id);


            if (temp == -1) {
                $scope.tempDocument.push(id);
            } else {
                $scope.tempDocument.splice(temp, 1);
            }
        }

        $scope.confirmDelete = function() {
            for (var i = 0; i < $scope.projectDetailsList.length; i++) {
                if ($scope.tempDocument != undefined) {
                    angular.forEach($scope.tempDocument, function(deletedItem) {
                        if ($scope.projectDetailsList != undefined) {
                            if (deletedItem == $scope.projectDetailsList[i].id) {
                                $scope.projectDetailsList.splice(i, 1);
                            }
                        }

                    });
                }
            }
            $scope.tempDocument = [];
            $scope.count = 0;
            FoundationApi.publish('deleteDocspopModal', 'close');
        }

    }
]);
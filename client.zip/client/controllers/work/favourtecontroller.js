myApp.controller('favourtecontroller', ['$scope', '$state', 'applicationModel', 'FoundationApi', 'config', 'restService',
    function($scope, $state, applicationModel, FoundationApi, config, restService) {

        $scope.count = 0;

        $scope.projectDetailsList = applicationModel.getModel().viewFavorite;

        $scope.tempFavorites = [];


        $scope.LoadProjectDetails = function(id) {
            $state.go('viewProjectDetails', {
                index: id,
            });
        }

        $scope.selectItem = function(id) {
            pushData(id);
            $scope.count = $scope.tempFavorites.length;
        }

        var pushData = function(id) {
            var temp = $scope.tempFavorites.indexOf(id);


            if (temp == -1) {
                $scope.tempFavorites.push(id);
            } else {
                $scope.tempFavorites.splice(temp, 1);
            }
        }


        $scope.confirmDelete = function() {

            angular.forEach($scope.tempFavorites, function(deletedItem) {
                // if ($scope.projectDetailsList != undefined) {
                var url = config.devURL.baseURL + config.devURL.deleteFavourite + deletedItem;

                for (var i = 0; i < $scope.projectDetailsList.length; i++) {

                    if ($scope.projectDetailsList[i].ID == deletedItem) {

                        $scope.projectDetailsList.splice(i, 1);

                    }
                };

                restService.getRequest(url, config.devURL.header, deleteSucessCallback, deleteFailureCallback);

            });

        }


        var deleteSucessCallback = function(response) {

            $scope.count--;

            if ($scope.count == 0) {
                $scope.tempFavorites = [];
                FoundationApi.publish('deleteDocspopModal', 'close');
            }

        }
        var deleteFailureCallback = function(response) {

            // $scope.go('error');

            deleteSucessCallback(response);
        }

    }
]);

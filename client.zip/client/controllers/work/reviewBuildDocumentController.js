myApp.controller('reviewBuildDocumentController', ['$scope', '$state', 'applicationModel','config', 
    function($scope, $state, applicationModel,config) {

    	$scope.documentFormat = config.documentFormat;

    	$scope.buildDocument = function() {
    		
    	}
    }
]);
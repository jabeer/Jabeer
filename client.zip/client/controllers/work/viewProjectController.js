/**
 * View project Controller First level
 */
myApp.controller('viewProjectController', ['$scope', '$state', 'config', 'FoundationApi', 'applicationModel', 'restService', 'loginModel', '$http',
    function($scope, $state, config, FoundationApi, applicationModel, restService, loginModel, $http) {

        $scope.tempProject = [];

        $scope.count = 0;

        $scope.projectDetailsList = applicationModel.getModel().viewProject;


        /* View project Details */
        $scope.LoadProjectDetails = function(item) {

            applicationModel.addModel("step2", item);

            $state.go('createdocument.step3');
        }




        $scope.showProperties = function() {
            if ($scope.tempProject != undefined) {
                $state.go('viewProjectDetails', {
                    index: $scope.tempProject[0],
                });
            }

        }


        /*
         * View project checked box functionality.
         * Using this we can delete, assign , Copy and see the properties.
         */
        $scope.checkBoxChecked = function(ServerRelativeUrl) {
            pushData(ServerRelativeUrl);
            $scope.count = $scope.tempProject.length;

            /* Hiding the tab bar to the bottom */
            var ele = document.getElementById("toggleText");
            var text = document.getElementById("displayText");
            var tabBar = document.getElementById("tabbar");
            if (ele.style.display == "block" & $scope.count == 0) {
                // ele.style.display = "none";
                tabBar.style.bottom = "0px";
            }
        }
        var pushData = function(item) {
                var temp = -1;

                temp = $scope.tempProject.indexOf(item.ID);


                if (temp == -1) {
                    $scope.tempProject.push(item.ID);
                } else {
                    $scope.tempProject.splice(item.ID, 1);;
                }

            }
            /* Confirm Delete functionality for View Project */
        $scope.confirmDelete = function() {
            for (var i = $scope.projectDetailsList.length - 1; i >= 0; i--) {
                if ($scope.tempProject != undefined) {
                    angular.forEach($scope.tempProject, function(deletedTask) {
                        if ($scope.projectDetailsList != undefined) {
                            if (deletedTask == $scope.projectDetailsList[i].ID) {
                                $scope.projectDetailsList.splice(i, 1);
                                var url = config.devURL.baseURL + config.devURL.deleteproject + $scope.projectDetailsList[i].UserId + config.devURL.filename + $scope.projectDetailsList[i].FileLeafRef;
                                restService.getRequest(url, config.devURL.header, deleteSuccess, deleteFailure);

                            }
                        }

                    });
                }
            }


        }

        var deleteSuccess = function(response) {
            $scope.tempProject = [];
            $scope.count = 0;
            FoundationApi.publish('deleteDocspopModal', 'close');

        }

        var deleteFailure = function(response) {
            // $state.go('error');
            deleteSuccess(response);
        }
        $scope.toggle = function() {
            var ele = document.getElementById("toggleText");
            var text = document.getElementById("displayText");
            var tabBar = document.getElementById("tabbar");
            if (ele.style.display == "block") {
                ele.style.display = "none";
                tabBar.style.bottom = "0px";
            } else {
                ele.style.display = "block";
                tabBar.style.bottom = "70px";
                ele.style.bottom = "0px";
                ele.style.position = "fixed";
            }
        }

        $scope.copyDocument = function(copyEIN) {

            angular.forEach($scope.tempProject, function(item) {
                var fileName = "";
                for (var i = $scope.projectDetailsList.length - 1; i >= 0; i--) {
                    if ($scope.projectDetailsList != undefined) {
                        if (item == $scope.projectDetailsList[i].ID) {
                            fileName = $scope.projectDetailsList[i].FileLeafRef;
                        }
                    }

                }

                var url = config.devURL.baseURL + config.devURL.copyProject + copyEIN + config.devURL.documentname + fileName;

                restService.getRequest(url, config.devURL.header, copyDocumentSuccess, copyDocumentFailure);

            });

        }

        var copyDocumentSuccess = function(response) {
            // $scope.tempProject = [];
            // $scope.count = 0;
            FoundationApi.publish('copypopModal', 'close');

        }

        var copyDocumentFailure = function(response) {
            // $state.go('error');
            copyDocumentSuccess(response);
        }


        $scope.assignDocument = function(copyEIN) {

            angular.forEach($scope.tempProject, function(item) {
                var ownerEin = "";
                for (var i = $scope.projectDetailsList.length - 1; i >= 0; i--) {
                    if ($scope.projectDetailsList != undefined) {
                        if (item == $scope.projectDetailsList[i].ID) {
                            ownerEin = $scope.projectDetailsList[i].UserId;
                        }
                    }

                }

                var url = config.devURL.baseURL + config.devURL.assignuser + item + config.devURL.ownerid + ownerEin + config.devURL.assignuserid + copyEIN;
                restService.getRequest(url, config.devURL.header, assignDocumentSuccess, assignDocumentFailure);

            });

        }

        var assignDocumentFailure = function(response) {
            // $state.go('error');
            assignDocumentSuccess(response);
        }

        var assignDocumentSuccess = function(response) {
            for (var i = $scope.projectDetailsList.length - 1; i >= 0; i--) {
                if ($scope.tempProject != undefined) {
                    angular.forEach($scope.tempProject, function(deletedTask) {
                        if ($scope.projectDetailsList != undefined) {
                            if (deletedTask == $scope.projectDetailsList[i].ID) {
                                $scope.projectDetailsList.splice(i, 1);
                            }
                        }

                    });
                }
            }
            $scope.tempProject = [];
            $scope.count = 0;
            FoundationApi.publish('assignpopModal', 'close');
        }

    }
]);
myApp.controller('viewTaskcontroller', ['$scope', '$state', 'config', 'FoundationApi', 'applicationModel', 'restService', '$sce', '$http',
    function($scope, $state, config, FoundationApi, applicationModel, restService, $sce, $http) {

        /* Count of the delete items in the task */
        $scope.count = 0;

        $scope.tempTask = [];

        if (applicationModel.getModel().viewTask != undefined) {

            $scope.viewTaskData = applicationModel.getModel().viewTask;

        }

        $scope.convertHTML = function(item) {

            if (item != undefined) {
                item = item.split("&lt;").join("<");
                item = item.split("&gt;").join(">");
                return $sce.trustAsHtml(item);
            }
        }


        $scope.deleteTask = function(item) {

            pushData(item);
            $scope.count = $scope.tempTask.length;

        }

        $scope.confirmDelete = function() {

            var itemdata = [];



            if ($scope.viewTaskData != undefined) {
                for (var i = 0; i < $scope.viewTaskData.length; i++) {
                    if ($scope.tempTask != undefined) {
                        angular.forEach($scope.tempTask, function(deletedTask) {

                            if (deletedTask.ID == $scope.viewTaskData[i].ID) {
                                $scope.viewTaskData.splice(i, 1);
                                itemdata.push({ "ID": deletedTask.ID });
                            }

                        });
                    }
                }
            }

            var url = config.devURL.baseURL + config.devURL.deleteTask;
            restService.postRequest(url, config.devURL.header, JSON.stringify({ itemData: itemdata }), deleteSucessCallback, deleteFailureCallback)

        }

        var deleteSucessCallback = function(response) {
            $scope.tempTask = [];
            $scope.count = 0;
            FoundationApi.publish('deleteDocspopModal', 'close');

        }

        var deleteFailureCallback = function(response) {
            deleteSucessCallback(response);
        }

        var pushData = function(item) {
            var temp = $scope.tempTask.indexOf(item.ID);


            if (temp == -1) {
                $scope.tempTask.push(item);
            } else {
                $scope.tempTask.splice(item.ID, 1);
            }
        }

        $scope.LoadtaskDetails = function(item) {

            applicationModel.addModel("viewtaskDetails", item);
            $state.go('viewtaskDetails');
        }
    }
]);

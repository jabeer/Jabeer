myApp.controller('viewtaskDetailsController', ['$scope', '$state', 'applicationModel',
    function($scope, $state, applicationModel) {

        $scope.item = applicationModel.getModel().viewtaskDetails;

        $scope.htmlComplie = function(item) {
            if (item != undefined) {
                item = item.split("&lt;").join("<");
                item = item.split("&gt;").join(">");
                return item;
            }
        }

    }
]);

myApp.factory('myService', function($http, $q, config) {

    return {

        file: '',

        makeRequest: function(url) {

            var deferred = $q.defer();

            var tempData = [];

            $http.get(url).then(function(resp) {

                for (var i = resp.data.length - 1; i >= 0; i--) {

                    angular.forEach(config.search_criteria, function(value) {
                        if (resp.data[i].file_type == value.name && value.selected) {
                            tempData.push(resp.data[i]);
                        }

                    });
                }
                deferred.resolve(tempData);

            });

            return deferred.promise;
        },

        getFile: function(key) {

            if (!this.file) {

                this.file = this.makeRequest("./projectdata/project_data.json");
            };

            return this.file;
        },

        getResponse: function(filename) {

            var temp ={};
            // var tempData = [];
            $http.get(filename).then(function(response) {

                return response.data.d;

            });

            return temp;
        }


    }
});
